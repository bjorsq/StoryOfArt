#!/bin/sh
cd `echo $0 | sed 's%[^/]*$%.%'`
echo "Adobe SVG Viewer installation folder is "`pwd`
echo "Searching for Mozilla..."
found=0
for mp in $HOME/mozilla*/plugins $HOME/*/mozilla*/plugins /usr/lib/mozilla*/plugins \
    /usr/local/mozilla*/plugins /usr/mozilla*/plugins /opt/mozilla*/plugins /usr/mozilla*/plugins
do
    if [ -d $mp ] ; then
	echo "Installing in $mp..."
	rm -f $mp/libNPSVG3.so
	ln -s `pwd`/libNPSVG3.so $mp
	found=1
    fi
done
if [ $found = "0" ] ; then
    echo "Mozilla installation not found"
fi


